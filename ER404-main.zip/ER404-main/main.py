from pyrogram import Client as Bot
from pyromod import listen
from config import API_ID, API_HASH, BOT_TOKEN

Client = Bot(
	"ER404",
	api_id=API_ID,
	api_hash=API_HASH,
	bot_token=BOT_TOKEN,
	plugins=dict(root="ERROR.komutlar")
)

with Client:
	Client.send_message("er4o4chat", "**@ReWoxi beni başarıyla çalıştırdı <3**")

print("ReWoxi beni başarıyla çalıştırdı <3")
Client.run()
