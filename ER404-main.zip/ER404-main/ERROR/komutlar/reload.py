from pyrogram import Client, filters
from pyrogram.types import Message
from config import BOT_NAME
import time

ADMIN = []

@Client.on_message(
	filters.command(["reload", f"reload@{BOT_NAME}"])
	& filters.group
)
async def reload(client, message):
	async for member in client.iter_chat_members(message.chat.id, filter="administrators"):
		for i in ADMIN:
			ADMIN.remove(i)
			time.sleep(0.2)
			ADMIN.append(member.user.id)

	await message.reply_text("Admin listesi yenilendi ✔")
	return