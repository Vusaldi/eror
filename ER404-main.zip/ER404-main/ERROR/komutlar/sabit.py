from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
import asyncio

def ipin(user_id, message_id):
	BUTTON = [[InlineKeyboardButton(text="🔔", callback_data =" ".join(["z_acik", str(user_id), str(message_id)])),
				InlineKeyboardButton(text="🔕", callback_data=" ".join(["z_kapali", str(user_id), str(message_id)]))]]
	BUTTON += [[InlineKeyboardButton(text="❌ İptal", callback_data =" ".join(["cls", str(user_id)]))]]
	return InlineKeyboardMarkup(BUTTON)

##################################
@Client.on_message(filters.command("pin") & filters.group)
async def pin(client, message):
	reply = message.reply_to_message
	user = message.from_user
	if not reply:
		await message.reply_text("**Lütfen bir mesaja yanıt verin.**")
		return
	if reply:
		await message.reply_text("**Bildiri Seçin?**",
			reply_markup=ipin(user.id, reply.message_id))


##################################

@Client.on_callback_query()
async def _(client, callback_query):
	user = callback_query.from_user
	chat = callback_query.message.chat

	sec, user_id, message_id = callback_query.data.split()
	if str(user.id) == str(user_id):
		if sec == "z_acik":
			await client.pin_chat_message(chat_id=chat.id, message_id=message_id, disable_notification=False)
			b = await callback_query.message.edit("**İstediğin mesaj sabitlendi.**")
			await asyncio.sleep(3)
			await callback_query.b.delete()
			return
		if sec == "z_kapali":
			await client.pin_chat_message(chat_id=chat.id, message_id=message_id, disable_notification=True)
			b = await callback_query.message.edit("**İstediğin mesaj sabitlendi.**")
			await asyncio.sleep(3)
			await callback_query.b.delete()
			return
		if sec == "cls":
			await client.delete_messages(
				chat_id=callback_query.message.chat.id,
				message_ids=callback_query.message.message_id)
			await callback_query.answer(text="İptal Edildi.", show_alert=False)
			return

	else:
		await callback_query.answer(text="Bu butonlar senin için değil dostum 😥", show_alert=True)
