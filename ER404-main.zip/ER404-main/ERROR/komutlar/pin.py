from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from config import BOT_NAME


@Client.on_message(
	filters.command(["sabit", f"sabit@{BOT_NAME}"])
	& filters.group
)
async def pin(client, message):
	reply = message.reply_to_message

	if not reply:
		await message.reply_text("Lütfen bir mesajı yanıtla.")
		return

	if reply:
		await client.pin_chat_message(chat_id=message.chat.id, message_id=reply.message_id, disable_notification=False)
		await message.reply_text("İsteğin mesajı sabitledim :)")