from pyrogram import Client, filters
from pyrogram.types import Message
from config import SUDO, BOT_NAME

GRP = []

PRV = []

@Client.on_message(
    filters.command(["stats", f"stats@{BOT_NAME}"])
    & (filters.private | filters.group)
)
async def sts(client, message):
    grp = len(GRP)
    pr = len(PRV)
    if message.from_user.id in SUDO:
        await message.reply_text(f"👥 Grup: {grp}\n👤 Kullanıcı: {pr}")
        return
