from pyrogram import Client, filters
from pyrogram.types import Message, ChatPermissions
import time
from config import BOT_NAME, SUDO
from pyrogram.errors import UserAdminInvalid

MUTER = []

@Client.on_message(
	filters.command("ytmute")
	& filters.group
)
async def ytmute(client, message):
	reply = message.reply_to_message

	if message.from_user.id in SUDO:
		if not reply:
			await message.reply_text("<b>Malesef bir kullanıcıya yanıt vermedin.</b>")
			return

		if reply:
			if reply.from_user.id in MUTER:
				await message.reply_text("<b>Malesef bu kullanıcı zaten MUTE yetkisine sahip.</b>")
				return

			else:
				MUTER.append(reply.from_user.id)
				await message.reply_text("<b>Kullanıcı `MUTER` listesine eklendi.</b>")
				return

	else:
		await message.reply_text("<b>Malesef sen SUDO kullanıcı değilsin.</b>")
		return

@Client.on_message(
	filters.command("rmute")
	& filters.group
)
async def rmute(client, message):
	rep = message.reply_to_message

	if message.from_user.id in SUDO:

		if not rep:
			await message.reply_text("<b>Malesef bir kullanıcıya yanıt vermedin.</b>")
			return

		if rep:
			us = rep.from_user.id
			if us in MUTER:
				MUTER.remove(rep.from_user.id)
				await message.reply_text("<b>Kullanıcı `MUTER` listesine çıkartıldı.</b>")
			else:
				await message.reply_text("<b>Malesef zaten listede olmayan bir kullanıcıyı nasıl listeden çıkartmamı bekliyorsun?</b>")

	else:
		await message.reply_text("<b>Malesef sen SUDO kullanıcı değilsin.</b>")
		return


@Client.on_message(
	filters.command(["mute", f"mute@{BOT_NAME}"])
	& filters.group
)
async def mute(client, message):
	repl = message.reply_to_message
	if message.from_user.id in MUTER:
		try:
			if not repl:
				await message.reply_text("Malesef bir kullanıcıya yanıt vermedin.")
				return
			else:
				await client.restrict_chat_member(message.chat.id, repl.from_user.id, ChatPermissions(can_send_messages=False))

				await message.reply_text(f"{repl.from_user.mention} mute atıldı.\n\nYetkili: {message.from_user.mention}")
				return
		except UserAdminInvalid:
			await message.reply_text("Bir yöneticiyi susturmamı nasıl düşünürsün 🙄")
			return
			
	if not message.from_user.id in MUTER:
		await message.reply_text("Malesef MUTE yetkisine sahip değilsin :(")
		return

@Client.on_message(
	filters.command(["unmute", f"unmute@{BOT_NAME}"])
	& filters.group
)
async def unmute(client, message):
	if message.from_user.id in MUTER:
		repl = message.reply_to_message

		if not repl:
			await message.reply_text("Malesef bir kullanıcıya yanıt vermedin.")
			return
		else:

			await client.restrict_chat_member(message.chat.id, repl.from_user.id, ChatPermissions(can_send_messages=True))
			await message.reply_text(f"{repl.from_user.mention} sesi açıldı.")
			return
	if not message.from_user.id in MUTER:
		await message.reply_text("Malesef BAN yetkisine sahip değilsin :(")
		return
