from pyrogram import Client, filters
from pyromod import listen
from pyrogram.types import Message
from config import BOT_NAME
import time

AG = -1001547827075

@Client.on_message(
	filters.command("ilet")
	& filters.private
)
async def report(client, message):
	sor = await client.ask(
		chat_id=message.chat.id,
		text=f"{message.from_user.mention} bu komut adminlere Şikayet/Öneri vs. iletmek için kodlandı.\n\nSeni dinliyorum yazdığın mesajı adminlere ileticem.")
	sr = sor.text
	time.sleep(0.5)
	await client.send_message(
		chat_id=AG,
		text=f"Gönderen: {message.from_user.mention}\nŞikayet/Öneri: {sr}")
	time.sleep(0.5)
	await message.reply_text("İsteğin başarıyla iletildi.")