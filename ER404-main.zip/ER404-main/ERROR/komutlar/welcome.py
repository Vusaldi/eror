from pyrogram import Client, filters
from pyrogram.types import Message
from config import SUDO

WELCOME = None
mention = None
firstname = None
id = None
chatname = None

@Client.on_message(
	filters.command("setwel")
	& filters.group
)
async def setw(client, message):
	global WELCOME
	if message.from_user.id in SUDO:
		msj = " ".join(message.command[1:])
		await message.reply_text("Welcome mesajı başarıyla kaydedildi.")
		WELCOME = msj
	if not message.from_user.id in SUDO:
		await message.reply_text(f"{message.from_user.mention} malesef sen sudo kullanıcı değilsin.")

@Client.on_message(filters.group & filters.new_chat_members)
async def welcome(client, message):
	global WELCOME
	global mention
	global firstname
	global id
	global chatname
	if WELCOME == None:
		pass
	else:
		for i in message.new_chat_members:
			mention = "[{}](tg://user?id={}".format(i.first_name, i.id)
			firstname = "{}".format(i.first_name)
			id = "{}".format(i.id)
			chatname = "{}".format(message.chat.title)
			await message.reply_text(f"{WELCOME}", disable_web_page_preview=True)


@Client.on_message(
	filters.command("resetwel")
	& filters.group
)
async def rstwel(client, message):
	global WELCOME
	if message.from_user.id in SUDO:
		await message.reply_text("Welcome mesajı sıfırlandı.")
		WELCOME = None
	if not message.from_user.id in SUDO:
		await message.reply_text(f"{message.from_user.mention} malesef sen sudo kullanıcı değilsin.")
