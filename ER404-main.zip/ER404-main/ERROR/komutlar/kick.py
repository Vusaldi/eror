from pyrogram import Client, filters
from pyrogram.types import Message
from config import BOT_NAME, SUDO
from pyrogram.errors import UserAdminInvalid


KICK_YT = []

@Client.on_message(
	filters.command("ytkick")
	& filters.group
)
async def yt_ban(client, message):
	reply = message.reply_to_message

	if message.from_user.id in SUDO:

		if not reply:
			await message.reply_text("Malesef bir kullanıcıya yanıt vermedin.")
			return

		if reply:
			user = reply.from_user
			if user.id in KICK_YT:
				await message.reply_text("Malesef bu kullanıcı zaten **KICK** yetkisine sahip.")
			else:
				KICK_YT.append(user.id)
				await message.reply_text("Kullanıcı `KICK_YT` listesine eklendi.")

	else:
		await message.reply_text("Malesef sen **SUDO** kullanıcı değilsin.")
		return



@Client.on_message(
	filters.command("rmkick")
	& filters.group
)
async def rmban(client, message):
	rep = message.reply_to_message

	if message.from_user.id in SUDO:

		if not rep:
			await message.reply_text("Malesef bir kullanıcıya yanıt vermedin.")
			return

		if rep:
			us = rep.from_user.id
			if us in KICK_YT:
				KICK_YT.remove(rep.from_user.id)
				await message.reply_text("Kullanıcı `KICK_YT` listesine çıkartıldı.")
			else:
				await message.reply_text("<b>Malesef zaten listede olmayan bir kullanıcıyı nasıl listeden çıkartmamı bekliyorsun?</b>")

	else:
		await message.reply_text("Malesef sen SUDO kullanıcı değilsin.")
		return


@Client.on_message(
	filters.command(["kick", f"kick@{BOT_NAME}"])
	& filters.group
)
async def kick(client, message):
	repl = message.reply_to_message
	async for member in client.iter_chat_members(message.chat.id, filter="administrators"):
		if message.from_user.id in KICK_YT:
			try:
				if not repl:
					await message.reply_text("Malesef bir kullanıcıya yanıt vermedin.")
					return
				else:
					await client.kick_chat_member(chat_id=message.chat.id, user_id=repl.from_user.id)
					await client.unban_chat_member(chat_id=message.chat.id, user_id=repl.from_user.id)

					await message.reply_text(f"{repl.from_user.mention} grubtan atıldı.\nYetkili: {message.from_user.mention}")
					return
			except UserAdminInvalid:
				await message.reply_text("Bir yöneticiyi grubtan atmamı nasıl düşünürsün 🙄")
				return
			
		if not message.from_user.id in KICK_YT:
			await message.reply_text("Malesef KICK yetkisine sahip değilsin :(")
			return
